import numpy as np

u = np.genfromtxt("2000/UMean_X.xy")

y = u[:, 0]
u = u[:, 1]

nu = 3.5e-4

uTau = np.sqrt(nu*u[0]/y[0])

print uTau

