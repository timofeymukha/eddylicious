import numpy as np

u = np.genfromtxt("2000/UMean_X.xy")

y = u[:, 0]
u = u[:, 1]

uC = np.max(u)

for i in xrange(u.size):
    if u[i] >=  0.99*uC:
        delta99 = y[i-1]
        break

print "Centerline velocity:", uC
print "delta_99: ", delta99
