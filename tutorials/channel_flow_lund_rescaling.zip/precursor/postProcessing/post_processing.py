import numpy as np
import os
import matplotlib.pyplot as plt

path = "collapsedFields/2000"

# Load DNS data
dnsU = np.genfromtxt("dns_mean.dat")
yDns = dnsU[:,0]
yPlusDns = dnsU[:,1]
dnsU = dnsU[:,2]

dnsUPrime2 = np.genfromtxt("dns_fluct.dat")[:,2]
dnsVPrime2 = np.genfromtxt("dns_fluct.dat")[:,3]
dnsWPrime2 = np.genfromtxt("dns_fluct.dat")[:,4]
dnsK = np.genfromtxt("dns_fluct.dat")[:,-1]
dnsShear = np.genfromtxt("dns_fluct.dat")[:,5]

dnsUTauOverUb = 1.0/np.trapz(dnsU, x=yDns)

nu = 3.5e-4

u = np.genfromtxt(os.path.join(path,"UMean_X.xy"))
y = u[:,0]
u = u[:,1]
uPrime2 = np.genfromtxt(os.path.join(path, "UPrime2Mean_XX.xy"))[:,1]
vPrime2 = np.genfromtxt(os.path.join(path, "UPrime2Mean_YY.xy"))[:,1]
wPrime2 = np.genfromtxt(os.path.join(path, "UPrime2Mean_ZZ.xy"))[:,1]
k = 0.5*(uPrime2 + vPrime2 + wPrime2)


shear = np.genfromtxt(os.path.join(path, "UPrime2Mean_XY.xy"))[:,1]
uTau = np.sqrt(nu*u[1]/y[1])
ub = 1

def u_y():
    plt.plot(y, u/ub, '-ro', label="Precursor")
    plt.plot(yDns, dnsU*dnsUTauOverUb, 'k', linewidth=2, label="DNS")
    plt.legend(loc=4)
    plt.xlabel(r"$y/\delta$")
    plt.ylabel(r"$<u>/U_b$")
    plt.xlim([0, 1])
    plt.grid()
    fig = plt.gcf()
    fig.set_size_inches(12,8, forward=True)

def uplus_yplus():
    plt.semilogx(y*uTau/nu, u/uTau, '-ro', label="Precursor")
    plt.semilogx(yPlusDns, dnsU, 'k', linewidth=2, label="DNS")
    plt.legend(loc=2)
    plt.xlabel(r"$y^+$")
    plt.ylabel(r"$<u>/u_\tau$")
    plt.xlim([0.5, 180])
    plt.grid()
    fig = plt.gcf()
    fig.set_size_inches(12,8, forward=True)
    
def uu():
    plt.plot(y, uPrime2/uTau**2, '-ro', label="Precursor")
    plt.plot(yDns, dnsUPrime2, 'k', linewidth=2, label="DNS")
    plt.legend()
    plt.xlabel(r"$y/\delta$")
    plt.ylabel(r"$<u'u'>/u^2_\tau$")
    plt.xlim([0, 1])
    plt.grid()
    fig = plt.gcf()
    fig.set_size_inches(12,8, forward=True)

def vv():
    plt.plot(y, vPrime2/uTau**2, '-ro', label="Precursor")
    plt.plot(yDns, dnsVPrime2, 'k', linewidth=2, label="DNS")
    plt.legend()
    plt.xlabel(r"$y/\delta$")
    plt.ylabel(r"$<v'v'>/u^2_\tau$")
    plt.xlim([0, 1])
    plt.grid()
    fig = plt.gcf()
    fig.set_size_inches(12,8, forward=True)

def ww():
    plt.plot(y, wPrime2/uTau**2, '-ro', label="Precursor")
    plt.plot(yDns, dnsWPrime2, 'k', linewidth=2, label="DNS")
    plt.legend()
    plt.xlabel(r"$y/\delta$")
    plt.ylabel(r"$<w'w'>/u^2_\tau$")
    plt.xlim([0, 1])
    plt.grid()
    fig = plt.gcf()
    fig.set_size_inches(12,8, forward=True)

def uv():    
    plt.plot(y, shear/uTau**2, '-ro', label="Precursor")
    plt.plot(yDns, dnsShear, 'k', linewidth=2, label="DNS")
    plt.legend()
    plt.xlabel(r"$y/\delta$")
    plt.ylabel(r"$<u'v'>/u^2_\tau$")
    plt.xlim([0, 1])
    plt.grid()
    fig = plt.gcf()
    fig.set_size_inches(12,8, forward=True)

def energy():    
    plt.plot(y, k/uTau**2, '-ro', label="Precursor")
    plt.plot(yDns, dnsK, 'k', linewidth=2, label="DNS")
    plt.legend()
    plt.xlabel(r"$y/\delta$")
    plt.ylabel(r"$<k>/u^2_\tau$")
    plt.xlim([0, 1])
    plt.grid()
    fig = plt.gcf()
    fig.set_size_inches(12,8, forward=True)
